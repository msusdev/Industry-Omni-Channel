﻿using System;

namespace PartsUnlimited.ViewModels
{
    public class ProductData
    {
        public string Title { get; set; }

        public string Url { get; set; }
    }
}